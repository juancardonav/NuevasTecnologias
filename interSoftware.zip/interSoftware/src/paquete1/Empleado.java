/*
 13 de deducciones
 */
package paquete1;

/**
 *
 * @author 505
 */
public class Empleado {
    
    //ATRIBUTOS = Datos = Variables
    
    public String nombre;
    public int cedula;
    public int salario;
    public String direcion;
    public String barrio;
    
    // METODOS = acciones == funciones
    
    //click derecho generar constructor
    public Empleado() {
        
    }

    public Empleado(String nombre) {
        this.nombre = nombre;
    }

    public Empleado(String nombre, int cedula, int salario, String direcion) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.salario = salario;
        this.direcion = direcion;
    }
    
    public double calcularSalario(int salarioBasico,int ventasExtras){
            
        double salarioTotal= (salarioBasico + ventasExtras)*0.73;

        return salarioTotal;
    }
    
    
    
}
