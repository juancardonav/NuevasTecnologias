/*
CACULAR SALARIO

Cantidad vendidos 

 */
package intersoftware;

import paquete1.Empleado;


/**
 *
 * @author 505
 */
public class InterSoftware {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int edad=50;
        
        //usar mi clase
        //crear un objeto
        
     Empleado empleado = new Empleado();

     System.out.println("nombre: "+empleado.nombre);
     empleado.nombre="pedro coral";
     System.out.println("nombre: "+empleado.nombre);
     
     empleado.cedula=4444444;
     System.out.println("Cedula: "+empleado.cedula);
     
     Empleado pachito=new Empleado("Pacho");
     System.out.println("nombre: "+pachito.nombre);
        
     Empleado objeto3=new Empleado("Yorlady", 10013621, 1000000, "caller larga");
     System.out.println("nombre: "+objeto3.nombre + " cedula: "+ objeto3.cedula + " con un salario: "+ objeto3.salario + " y vive en: "+objeto3.direcion);
       
         
     Empleado salario=new Empleado()     

    }
    
}
